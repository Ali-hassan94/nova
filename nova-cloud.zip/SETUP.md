# Nova cloud version: setup (sab free)

Ye version Tailscale ke bagair chalta hai. Har banda apna account banata hai, apna data alag hota hai,
aur Nova us ke apne phone ko control karti hai.
PC control is version mein band hai (wo alag "PC Agent" se aayega, agla marhala).

## 1. Database (Supabase)
1. Supabase project kholen, SQL Editor mein `api/nova-cloud-migration.sql` chalayein.
   Chalane se pehle file mein `CHANGE_ME_STRONG_PASSWORD` apna lamba password bana dein.
2. Project Settings > Database > Connection string mein **Session pooler** (port 5432) wali string lein.
   Username `postgres.xxxx` ki jagah `nova_app.xxxx` likhein, password wohi jo upar rakha.
   Transaction pooler (port 6543) use mat karein, wo is design ke saath nahi chalta.

## 2. Server (Render free web service, Docker)
1. `api/` folder ko GitHub repo mein daalein.
2. Render > New Web Service > repo chunein > Runtime: Docker.
3. Environment variables:
   - `ConnectionStrings__Supabase` = Npgsql format, jaise `Host=...;Port=5432;Database=postgres;Username=nova_app.xxxx;Password=...;SSL Mode=Require;Trust Server Certificate=true`
   - `Jarvis__TokenSecret` = 40+ random haroof (kisi ko mat batayein)
   - `Jarvis__InviteCode` = koi code jo aap dosto ko denge (khali chhora to koi bhi account bana sakta hai)
   - `Groq__ApiKey` (aur jo pehle Gemini/Groq keys aur models aap ki appsettings/user-secrets mein the)
4. Deploy ke baad `https://<naam>.onrender.com/health` Chrome mein kholen. `{"status":"ok"}` aana chahiye.

## 3. Mobile app (GitHub Actions se APK)
1. `MainActivity.kt` mein `DEFAULT_BASE` ko apne Render address se badlein.
2. `mobile/` ko GitHub repo mein daalein. Actions tab > "Build Nova APK" > Run workflow.
3. Artifact `nova-apk` download karein, APK doston ko bhej dein.
4. App kholen > Settings > email, password, invite code > "Naya account".

## Dhyan rakhne wali baatein
- Ye code is chat mein compile ya test nahi hua (yahan .NET aur Android build tools nahi hain).
  Pehli build mein chhoti errors aa sakti hain, error bhej dein, theek kar dunga.
- Free server so jata hai, pehli request mein kuch der lagti hai. Free limits aap Render ki site par check kar lein.
- Groq ki free limit sab users mein shared hai.
- Purana data apne naye account ko dene ke liye migration file ke aakhir mein optional hissa hai.
